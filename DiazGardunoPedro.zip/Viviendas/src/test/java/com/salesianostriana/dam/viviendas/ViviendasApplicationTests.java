package com.salesianostriana.dam.viviendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViviendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
