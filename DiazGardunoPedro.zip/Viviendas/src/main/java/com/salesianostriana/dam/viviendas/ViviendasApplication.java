package com.salesianostriana.dam.viviendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class    ViviendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViviendasApplication.class, args);
	}

}
