package com.salesianostriana.dam.viviendas.Model;

public enum EstadoVivienda {
    NUEVA,
    SEGUNDA_MANO,
    REFORMAR
}
