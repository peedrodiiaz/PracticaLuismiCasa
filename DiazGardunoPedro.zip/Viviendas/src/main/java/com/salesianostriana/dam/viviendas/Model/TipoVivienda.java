package com.salesianostriana.dam.viviendas.Model;

public enum TipoVivienda {
    PISO,
    CASA,
    ATICO,
    DUPLEX,
    CHALET
}
